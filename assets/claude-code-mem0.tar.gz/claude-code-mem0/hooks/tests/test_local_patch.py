"""Tests for the local patch: real Claude Code Stop payload (transcript_path), incremental saves, redaction."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
import stop  # noqa: E402
from common import redact  # noqa: E402


def _transcript(tmp_path, rows):
    p = tmp_path / "t.jsonl"
    p.write_text("\n".join(json.dumps(r) for r in rows))
    return str(p)


def _u(uid, text):
    return {"type": "user", "uuid": uid, "message": {"role": "user", "content": text}}


def _a(uid, parts):
    return {"type": "assistant", "uuid": uid, "message": {"role": "assistant", "content": parts}}


def test_reads_transcript_path_and_skips_noise(tmp_path, monkeypatch):
    monkeypatch.setattr(stop, "STATE", tmp_path / "state")
    path = _transcript(tmp_path, [
        _u("1", "find CCTV partners in Pune"),
        _a("2", [{"type": "thinking", "thinking": "secret plan"}, {"type": "text", "text": "Found 12 partners."}]),
        _u("3", [{"type": "tool_result", "content": "raw tool output"}]),
        {"type": "attachment", "uuid": "4"},
        {"type": "assistant", "uuid": "5", "isSidechain": True, "message": {"role": "assistant", "content": [{"type": "text", "text": "subagent"}]}},
    ])
    msgs, last, _ = stop.extract_messages({"transcript_path": path, "session_id": "s1"}, 10)
    assert [m["content"] for m in msgs] == ["find CCTV partners in Pune", "Found 12 partners."]
    assert last == "2"


def test_incremental_saves_do_not_repeat(tmp_path, monkeypatch):
    monkeypatch.setattr(stop, "STATE", tmp_path / "state")
    rows = [_u("1", "first prompt here"), _a("2", [{"type": "text", "text": "first answer"}])]
    path = _transcript(tmp_path, rows)
    msgs, last, state_f = stop.extract_messages({"transcript_path": path, "session_id": "s2"}, 10)
    assert len(msgs) == 2
    (tmp_path / "state").mkdir()
    state_f.write_text(json.dumps({"last_uuid": last}))
    rows += [_u("3", "second prompt here"), _a("4", [{"type": "text", "text": "second answer"}])]
    path = _transcript(tmp_path, rows)
    msgs, last, _ = stop.extract_messages({"transcript_path": path, "session_id": "s2"}, 10)
    assert [m["content"] for m in msgs] == ["second prompt here", "second answer"]


def test_redacts_secrets():
    s = redact("token apify_api_ABCDEFGHIJKLMNOPQRSTUVWX and m0-abcdefghijklmnopqrstuvwxyz12 and APIFY_TOKEN=abc123def456")
    assert "apify_api_ABC" not in s and "m0-abc" not in s and "abc123def456" not in s
    assert redact("plain sentence about CCTV dealers") == "plain sentence about CCTV dealers"


def test_missing_transcript_file_is_silent(tmp_path, monkeypatch):
    monkeypatch.setattr(stop, "STATE", tmp_path / "state")
    msgs, last, _ = stop.extract_messages({"transcript_path": str(tmp_path / "nope.jsonl"), "session_id": "s3"}, 10)
    assert msgs == [] and last is None
