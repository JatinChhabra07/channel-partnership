#!/usr/bin/env python3
"""
mem0 UserPromptSubmit Hook
Searches mem0 for relevant memories before each prompt and injects them into context.
Also saves each user prompt to mem0 for continuous learning.

Environment Variables:
  (self-hosted: no API key; store at ~/.channel-partnership/mem0)
  MEM0_USER_ID: Optional - User identifier for memory scoping (default: claude-code-user)
  MEM0_TOP_K: Optional - Number of memories to retrieve (default: 5)
  MEM0_THRESHOLD: Optional - Minimum similarity score (default: 0.3)
  MEM0_AUTO_SAVE: Optional - Auto-save prompts to memory (default: true)
"""

import json
import os
import sys
import threading
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from common import load_env_file, redact  # noqa: E402  (local patch)
from localmem import open_memory, USER_ID  # noqa: E402  (self-hosted mem0)


def get_config():
    """Get configuration from environment variables."""
    return {
        "enabled": os.environ.get("MEM0_DISABLED", "") == "",
        "user_id": os.environ.get("MEM0_USER_ID") or USER_ID,
        "top_k": int(os.environ.get("MEM0_TOP_K", "5")),
        "threshold": float(os.environ.get("MEM0_THRESHOLD", "0.3")),
        "auto_save": os.environ.get("MEM0_AUTO_SAVE", "true").lower() == "true",
    }


def search_memories(query: str, config: dict, mem) -> list:
    """Search the local mem0 store (self-hosted; replaces upstream's cloud MemoryClient)."""
    if mem is None:
        return []
    try:
        response = mem.search(query, filters={"user_id": config["user_id"]}, top_k=config["top_k"], threshold=config["threshold"])
        return response.get("results", []) if isinstance(response, dict) else (response or [])
    except Exception as e:  # noqa: BLE001
        print(f"mem0 search error: {e}", file=sys.stderr)
        return []


def save_prompt_async(prompt: str, config: dict, mem):
    """Save the (redacted) prompt verbatim. infer=False: no LLM, exact text."""
    if mem is None:
        return
    try:
        mem.add([{"role": "user", "content": redact(prompt)}], user_id=config["user_id"],
                metadata={"source": "claude-code-prompt"}, infer=False)
    except Exception as e:  # noqa: BLE001
        print(f"mem0 auto-save error: {e}", file=sys.stderr)


def format_memories(results: list) -> str:
    """Format memories for context injection."""
    memories = []
    for r in results:
        memory = r.get("memory", "")
        if memory:
            # Include category if available
            categories = r.get("categories", [])
            if categories:
                memories.append(f"- [{', '.join(categories)}] {memory}")
            else:
                memories.append(f"- {memory}")

    if not memories:
        return ""

    return "## Relevant memories from previous conversations:\n" + "\n".join(memories)


def main():
    # Load environment from .env file
    load_env_file()

    # Read hook input from stdin
    try:
        input_data = json.load(sys.stdin)
    except json.JSONDecodeError:
        sys.exit(0)

    # Get user prompt (field is "prompt" per Claude Code spec)
    user_prompt = input_data.get("prompt", "") or input_data.get("user_prompt", "")
    if not user_prompt:
        sys.exit(0)

    # Get configuration
    config = get_config()

    # Check for API key
    if not config["enabled"]:
        sys.exit(0)
    mem = open_memory(wait_s=3.0)

    # Search for relevant memories
    results = search_memories(user_prompt, config, mem)

    # Auto-save this prompt to mem0 (in background)
    if config["auto_save"] and len(user_prompt.strip()) >= 20:
        save_prompt_async(user_prompt, config, mem)

    # Format and output memories as plain text (correct format for context injection)
    if results:
        message = format_memories(results)
        if message:
            # Plain text output with exit 0 injects as context
            print(message)


if __name__ == "__main__":
    main()
