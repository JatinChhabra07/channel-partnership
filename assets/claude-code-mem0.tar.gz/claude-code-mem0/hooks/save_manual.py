#!/usr/bin/env python3
"""
mem0 Manual Save Script
Saves provided messages to mem0 memory.

Usage: echo '{"messages": [...]}' | python3 save_manual.py
Or: python3 save_manual.py "message to save"
"""

import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from common import load_env_file, redact  # noqa: E402  (local patch)
from localmem import open_memory, USER_ID  # noqa: E402  (self-hosted mem0)


def get_config():
    """Get configuration from environment variables."""
    return {
        "enabled": os.environ.get("MEM0_DISABLED", "") == "",
        "user_id": os.environ.get("MEM0_USER_ID") or USER_ID,
    }


def save_memories(messages: list, config: dict) -> dict:
    """Save messages to mem0."""
    mem = open_memory()
    if mem is None:
        return {"success": False, "error": "local mem0 store unavailable or busy"}
    try:
        result = mem.add([{**m, "content": redact(m.get("content", ""))} for m in messages],
                         user_id=config["user_id"], metadata={"source": "manual-save"}, infer=False)
        return {"success": True, "result": result}
    except Exception as e:
        return {"success": False, "error": str(e)}


def main():
    # Load environment from .env file
    load_env_file()

    # Get configuration
    config = get_config()

    # Check for API key
    if not config["enabled"]:
        print(json.dumps({"success": False, "error": "mem0 disabled (MEM0_DISABLED set)"}))
        sys.exit(1)

    # Get messages from stdin or command line
    messages = []

    if len(sys.argv) > 1:
        # Message provided as command line argument
        content = " ".join(sys.argv[1:])
        messages = [{"role": "user", "content": content}]
    else:
        # Try to read from stdin
        try:
            input_data = json.load(sys.stdin)
            if isinstance(input_data, dict) and "messages" in input_data:
                messages = input_data["messages"]
            elif isinstance(input_data, list):
                messages = input_data
        except:
            print(json.dumps({"success": False, "error": "No messages provided"}))
            sys.exit(1)

    if not messages:
        print(json.dumps({"success": False, "error": "No messages to save"}))
        sys.exit(1)

    # Save to mem0
    result = save_memories(messages, config)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
