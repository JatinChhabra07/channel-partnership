#!/usr/bin/env python3
"""
mem0 Stop Hook (locally patched; upstream 5e996ec read a non-existent `transcript` field and never saved).

Claude Code's Stop payload carries `transcript_path` (a JSONL file) and fires after EVERY assistant reply,
so this hook saves only messages not yet saved for this session (state in ~/.claude/local-plugins/.mem0-state).

Environment Variables:
  (self-hosted: no API key; store at ~/.channel-partnership/mem0)
  MEM0_USER_ID        memory scope (default: claude-code-user)
  MEM0_SAVE_MESSAGES  max new messages sent per stop (default: 10)
"""
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from common import load_env_file, redact  # noqa: E402
from localmem import open_memory, USER_ID  # noqa: E402  (self-hosted mem0)

STATE = Path.home() / ".claude" / "local-plugins" / ".mem0-state"


def get_config():
    return {
        "enabled": os.environ.get("MEM0_DISABLED", "") == "",
        "user_id": os.environ.get("MEM0_USER_ID") or USER_ID,
        "save_messages": int(os.environ.get("MEM0_SAVE_MESSAGES", "10")),
    }


def _text(content) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):  # keep prose only: skip thinking, tool_use, tool_result
        return " ".join(p.get("text", "") for p in content if isinstance(p, dict) and p.get("type") == "text")
    return ""


def read_transcript(path: str) -> list:
    """[(uuid, role, text)] for real user prompts and assistant prose, main thread only."""
    out = []
    try:
        with open(path) as f:
            for line in f:
                try:
                    d = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if d.get("type") not in ("user", "assistant") or d.get("isSidechain"):
                    continue
                msg = d.get("message") or {}
                text = _text(msg.get("content")).strip()
                if not text or text.startswith("<") and "system-reminder" in text[:200]:
                    continue
                out.append((d.get("uuid"), msg.get("role") or d["type"], text))
    except OSError:
        pass
    return out


def extract_messages(input_data: dict, max_messages: int) -> tuple:
    """Return (messages, last_uuid). Backwards compatible with the upstream `transcript` list shape."""
    if input_data.get("transcript"):
        rows = [(None, m.get("role", ""), _text(m.get("content", ""))) for m in input_data["transcript"]]
    else:
        rows = read_transcript(input_data.get("transcript_path", ""))
    sid = input_data.get("session_id")
    state_f = STATE / f"{sid}.json" if sid else None
    last = json.loads(state_f.read_text()).get("last_uuid") if state_f and state_f.exists() else None
    if last:
        idx = next((i for i, r in enumerate(rows) if r[0] == last), None)
        rows = rows[idx + 1:] if idx is not None else rows
    rows = rows[-max_messages:]
    messages = []
    for _, role, content in rows:
        if role and content:
            content = redact(content)
            messages.append({"role": role, "content": content[:2000] + ("..." if len(content) > 2000 else "")})
    new_last = rows[-1][0] if rows else last
    return messages, new_last, state_f


def save_memories(messages: list, config: dict) -> bool:
    mem = open_memory(wait_s=5.0)
    if mem is None:
        return False
    try:
        mem.add(messages, user_id=config["user_id"], metadata={"source": "claude-code-session"}, infer=False)
        return True
    except Exception as e:  # noqa: BLE001
        print(f"mem0 save error: {e}", file=sys.stderr)
    return False


def main():
    load_env_file()
    try:
        input_data = json.load(sys.stdin)
    except json.JSONDecodeError:
        sys.exit(0)
    if input_data.get("stop_hook_active"):
        sys.exit(0)
    config = get_config()
    if not config["enabled"]:
        sys.exit(0)
    messages, new_last, state_f = extract_messages(input_data, config["save_messages"])
    if not messages:
        sys.exit(0)
    if save_memories(messages, config) and state_f and new_last:
        STATE.mkdir(parents=True, exist_ok=True)
        state_f.write_text(json.dumps({"last_uuid": new_last}))


if __name__ == "__main__":
    main()
