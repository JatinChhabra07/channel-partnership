"""Shared helpers for the mem0 hooks (local patch on top of upstream 5e996ec).

Changes vs upstream:
  * env: project .env, then MEM0_ENV_FILE if set (lets a workspace point at ~/.channel-partnership/.env)
  * redact(): strips API keys / tokens before anything leaves the machine
"""
import os
import re
from pathlib import Path

SECRET_PATTERNS = [
    r"apify_api_[A-Za-z0-9]{20,}", r"\bm0-[A-Za-z0-9]{20,}", r"\bsk-(?:ant-|proj-)?[A-Za-z0-9_-]{20,}",
    r"\bAKIA[0-9A-Z]{16}\b", r"\bgh[pousr]_[A-Za-z0-9]{30,}", r"\bxox[abprs]-[A-Za-z0-9-]{10,}",
    r"\bAIza[0-9A-Za-z_-]{35}\b", r"\bya29\.[0-9A-Za-z_-]{20,}", r"-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]+?-----END [A-Z ]*PRIVATE KEY-----",
    r"(?i:\b[A-Z_]*(?:api[_-]?key|token|secret|password|passwd)\s*[:=]\s*\S{8,})",
]
_SECRET_RE = re.compile("|".join(f"(?:{p})" for p in SECRET_PATTERNS))


def redact(text: str) -> str:
    return _SECRET_RE.sub("[REDACTED]", text or "")


def _load(path: Path):
    if path.exists():
        for line in path.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                v = v.strip().strip('"').strip("'")
                if v:
                    os.environ.setdefault(k.strip(), v)


def load_env_file():
    project_dir = os.environ.get("CLAUDE_PROJECT_DIR", "")
    if project_dir:
        _load(Path(project_dir) / ".env")
    extra = os.environ.get("MEM0_ENV_FILE")
    if extra:
        _load(Path(os.path.expanduser(extra)))
